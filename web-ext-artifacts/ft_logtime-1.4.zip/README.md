# 42logtime
Simple Firefox extension I created on a whim, it sums up the logtime of a user's current month on intra.42.fr.
It will trigger an alert with the user's logtime every time they refresh their profile page.

If you'd like to use it, just upload the file `web-ext-artifacts/logtime-1.0-an+fx.xpi` to **Menu > Add-ons > Settings cog > Install Add-on From File** in your Firefox browser.

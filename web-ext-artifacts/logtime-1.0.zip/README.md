# 42logtime
Simple Firefox extension that sums up the logtime of a user's current month on intra.42.fr.

# ft_logtime
A simple Firefox extension that sums up the logtime of a user's current month on their profile at [intra.42.fr](intra.42.fr) and shows it in their logtime section.
The sum is updated every time the page is reloaded.

<img width="579" alt="Screen Shot 2020-12-21 at 5 49 24 PM" src="https://user-images.githubusercontent.com/6943864/102802015-525f0580-43b6-11eb-82b6-c0440b882a32.png">

If you'd like to use it, just download the file `web-ext-artifacts/ft_logtime-1.4-an+fx.xpi` and upload it to **Menu > Add-ons > Settings cog > Install Add-on From File** in your Firefox browser.
